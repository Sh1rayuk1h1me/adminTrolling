import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) {
        JFrame window1 = new JFrame();
        window1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window1.setVisible(true);
        window1.setSize(400,300);
        window1.getContentPane().setLayout(null);

        JButton button1 = new JButton();
        button1.setText("Inject");
        button1.setBackground(Color.RED);
        button1.setSize(200,100);
        button1.setLocation(100, 80);
        ActionListener AListener1 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("scam");
                try {
                    Desktop.getDesktop().browse(new URI("https://www.youtube.com/watch?v=S-L3pdD3VPs"));
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (URISyntaxException ex) {
                    throw new RuntimeException(ex);
                }
            }
        };
        button1.addActionListener(AListener1);
        window1.add(button1);
    }
}